﻿===============================================
Geo-Metro: A linework set from Project Linework
===============================================

Linework drawn by Daniel P. Huffman

Released to the public domain. Please credit the author and the project wherever possible.



REVISION HISTORY

Version 1.2 — 10/04/2013
-----------------------
ADMIN-0 POLY: Cleaned up topology in shapfiles
ADMIN-1 POLY: Cleaned up topology in shapefiles
WATERBODIES: Cleaned up topology in shapefiles
ADMIN-0 LINES: New shapefile and AI layer
ADMIN-1 LINES: New shapefile and AI layer
Add TopoJSON


Version 1.1 — 11/21/2012
------------------------
ADMIN-0: Add ISO3166, SOVEREIGN, FORMAL attributes to shapefile
ADMIN-1: Add ISO3166_2 and COUNTRY attributes to shapefile


Version 1.0 — 7/18/2012
-----------------------
Initial release