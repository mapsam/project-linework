﻿===========================================
Liana: A linework set from Project Linework
===========================================

Linework drawn by Sarah Bennett.

Released to the public domain. Please credit the author and the project wherever possible.



REVISION HISTORY

Version 1.1  — 10/04/2013
------------------------
COAST, ADMIN0, ADMIN1, LAKES: Clean up geometry errors
Add GeoJSON files
Include Great Lakes as part of COAST
Add TopoJSON files


Version 1.0  — 7/18/2012
------------------------
Initial release