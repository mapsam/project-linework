Liana: A linework set from Project Linework
Linework drawn by Sarah Bennett.

Released to the public domain. Please credit the author and the project wherever possible.

REVISION HISTORY

Version 1.0  — 7/18/2012
----------
Initial release